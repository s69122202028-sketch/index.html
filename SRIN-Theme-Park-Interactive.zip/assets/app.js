
const DATA = {
  "Entrance": [["Main Street",2],["Parking",1]],
  "Main Street": [["Entrance",2],["Castle",3],["Food Court",3]],
  "Castle": [["Main Street",3],["Roller Coaster",4],["Ferris Wheel",2],["Water Park",2]],
  "Roller Coaster": [["Castle",4],["Water Park",2]],
  "Water Park": [["Castle",2],["Roller Coaster",2],["Food Court",5]],
  "Ferris Wheel": [["Castle",2],["Carousel",3],["Food Court",5]],
  "Carousel": [["Ferris Wheel",3],["Food Court",1]],
  "Food Court": [["Main Street",3],["Water Park",5],["Ferris Wheel",5],["Carousel",1]],
  "Parking": [["Entrance",1]]
};

const ICONS = {"Entrance":"🚪","Main Street":"🛍️","Castle":"🏰","Roller Coaster":"🎢","Water Park":"💦","Ferris Wheel":"🎡","Carousel":"🎠","Food Court":"🍔","Parking":"🅿️"};

function neighbors(v){ return DATA[v] || []; }

function bfs(start, goal){
  const q=[[start]], seen=new Set([start]);
  while(q.length){const path=q.shift(), v=path.at(-1); if(v===goal)return path;
    for(const [n] of neighbors(v)) if(!seen.has(n)){seen.add(n);q.push([...path,n]);}}
  return [];
}
function dfs(start, goal){
  const stack=[[start]], seen=new Set();
  while(stack.length){const path=stack.pop(),v=path.at(-1); if(seen.has(v))continue; seen.add(v); if(v===goal)return path;
    [...neighbors(v)].reverse().forEach(([n])=>{if(!seen.has(n))stack.push([...path,n])});}
  return [];
}
function dijkstra(start, goal){
  const dist=Object.fromEntries(Object.keys(DATA).map(k=>[k,Infinity])), prev={}; dist[start]=0;
  const unvisited=new Set(Object.keys(DATA));
  while(unvisited.size){
    let u=[...unvisited].reduce((a,b)=>dist[a]<dist[b]?a:b);
    unvisited.delete(u); if(u===goal||dist[u]===Infinity)break;
    for(const [v,w] of neighbors(u)){const alt=dist[u]+w;if(alt<dist[v]){dist[v]=alt;prev[v]=u;}}
  }
  if(dist[goal]===Infinity)return {path:[],distance:Infinity};
  const path=[]; for(let v=goal;v;v=prev[v])path.unshift(v); return {path,distance:dist[goal]};
}
function renderPath(path){return path.length?path.map((v,i)=>`${i? "→ ":""}${ICONS[v]} ${v}`).join(" "):"ไม่พบเส้นทาง"}
function fillSelect(id){const el=document.getElementById(id); if(!el)return; Object.keys(DATA).forEach(v=>el.add(new Option(`${ICONS[v]} ${v}`,v)));}

document.addEventListener("DOMContentLoaded",()=>{
  fillSelect("start");fillSelect("goal");
  const run=document.getElementById("runRoute");
  if(run) run.onclick=()=>{
    const s=document.getElementById("start").value,g=document.getElementById("goal").value,algo=document.getElementById("algo").value;
    let p=algo==="BFS"?bfs(s,g):algo==="DFS"?dfs(s,g):dijkstra(s,g).path;
    document.getElementById("routeResult").innerHTML=`<b>${algo}</b><br>${renderPath(p)}`;
    if(algo==="Dijkstra"){const d=dijkstra(s,g);document.getElementById("routeMeta").textContent=d.path.length?`ระยะทางรวม ${d.distance} หน่วย`:'';}
  };
  const demo=document.getElementById("demoRoute");
  if(demo) demo.onclick=()=>{document.getElementById("start").value="Entrance";document.getElementById("goal").value="Roller Coaster";document.getElementById("algo").value="Dijkstra";run.click();};

  const search=document.getElementById("rideSearch");
  if(search) search.oninput=()=>{const q=search.value.toLowerCase();document.querySelectorAll(".ride").forEach(c=>c.style.display=c.innerText.toLowerCase().includes(q)?"":"none")};

  const treeButtons=document.querySelectorAll("[data-tree]");
  treeButtons.forEach(b=>b.onclick=()=>{
    document.querySelectorAll("[data-tree]").forEach(x=>x.classList.remove("active"));b.classList.add("active");
    const mode=b.dataset.tree, out=document.getElementById("treeResult");
    const preorder=["SRIN Theme Park","Rides","Roller Coaster","Water Park","Attractions","Castle","Ferris Wheel","Food & Drink","Food Court","Facilities","Restroom","Parking"];
    const postorder=["Roller Coaster","Water Park","Rides","Castle","Ferris Wheel","Attractions","Food Court","Food & Drink","Restroom","Parking","Facilities","SRIN Theme Park"];
    const bfsOrder=["SRIN Theme Park","Rides","Attractions","Food & Drink","Facilities","Roller Coaster","Water Park","Castle","Ferris Wheel","Food Court","Restroom","Parking"];
    const list=mode==="pre"?preorder:mode==="post"?postorder:bfsOrder;
    out.textContent=list.join(" → ");
  });
});
