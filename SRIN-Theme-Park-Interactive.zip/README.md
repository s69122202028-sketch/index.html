# SRIN Theme Park — Interactive Web Application

4 หน้า:
1. Home — หน้าต้อนรับและภาพแผนที่
2. Map — แผนที่สถานที่แบบ interactive
3. Graph — Adjacency List + BFS/DFS/Dijkstra + weighted graph
4. Tree — Tree 3 ระดับ + Root/Parent/Child/Leaf + Path + Traversal
5. Rides — รายการสถานที่และกิจกรรม

วิธีใช้:
- เปิด index.html ใน browser ได้ทันที
- หากใช้ GitHub Pages ให้อัปโหลดทั้งโฟลเดอร์โดยรักษาโครงสร้าง assets/
- ไม่ต้องติดตั้งฐานข้อมูลหรือ backend
